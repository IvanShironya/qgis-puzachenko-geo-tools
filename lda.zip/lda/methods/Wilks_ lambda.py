# -*- coding: utf-8 -*-

import numpy as np
import scipy.stats as st
import pandas as pd
import math

# from memory_profiler import profile


# @profile
def symmetric_sweep(matrix):
    '''
    Возращает симметричную развертку для заданной ковариационной матрицы. 
    Оператор развертки (Dempster, 1969), - SWP. SWP позволяет быстро 
    регрессировать все переменные относительно одной указанной переменной, 
    получая оценки Метода Наименьших Квадратов для коэффициентов регрессии 
    и дисперсий 
    '''

    n = matrix.shape[0]
    swp_matrix = np.copy(matrix)

    # строки
    for k in range(n):
        
        # строки ниже текущей
        for i in range(k+1, n):
            
            # столбцы справа от текущего диагонального элемента
            for j in range(i, n):
                
                # вычитаем произведение элементов в строке i столбце k и строке k столбце j, 
                # деленное на диагональный элемент в строке k столбце k из элемента 
                # в строке i столбце j. 
                # Верхняя матрица становится треугольной (алгоритм симметричной развертки)
                if swp_matrix[k,k] == 0:
                    epsilon = 1e-10  # Малое значение для регуляризации
                    swp_matrix[k,k] += epsilon
                
                swp_matrix[i,j] -= (swp_matrix[i,k] * swp_matrix[k,j]) / swp_matrix[k,k]
                
                # делаем матрицу симметричной
                swp_matrix[j,i] = swp_matrix[i,j]

    return swp_matrix

# @profile
def rao_stat(list_entered, g, n, wl):
    '''
    Статистика Approximate F, известная как Rao’s R (Tatsuoka, 1971)
    list_entered - переменные в моделе 
    g - количество групп
    n - количество наблюдений (общее)
    wl - текущая Wilks' L.
    Функция возвращает степени свободы и F-статистику
    Апроксимация точная когда q или h равняются 1 или 2.
    '''

    q = len(list_entered)
    h = g - 1
    r = n - 1 - (q + g) / 2

    # степень для Wilks' L. в формуле для F RAO
    if  q ** 2 + h ** 2 != 5:
        
        s = math.sqrt(
            (q ** 2 + h ** 2 - 5) / (q ** 2 * h ** 2 - 4)
        )
    
    else:
        s = 1

    rao_df1 = q * h
    rao_df2 =  r / s + 1 - (q * h) / 2
    rao_f = ((1 - (wl ** s)) * rao_df2) / ((wl ** s) * rao_df1)

    return rao_df1, rao_df2, rao_f

# @profile
def method(W, V, features, num_groups, num_samples, f_enter, f_del, verbose=True):
    ''''''
    
    print('\nExecuting stepwise method for selecting ' 
          'variables for discriminant analysis...\n'
          )

    # инициализация переманной для подсчета шагов
    step = 1

    # инициализация Wilks' L.
    wilks_l = np.inf
    
    # инициализация Wilks' L. для первого шага
    wilks_temp = 1.

    # инициализация максимального F-value
    f_val_add = -np.inf

    # инициализация p-value
    p_val_add = None

    # инициализация индекса переменной для добавления в модель
    idx_add_first = None

    # инициализация списка переменных добавленных в модель
    list_var_entered = []
    
    # добавление 1ой переменной в модель
    for feature in features:

        # промежуточная матрица числителя для формулы Лямбды Уилкса
        w_temp = W[:, [feature]]
        w_temp = w_temp[[feature], :]

        # промежуточная матрица знаменателя для формулы Лямбды Уилкса
        v_temp = V[:, [feature]]
        v_temp = v_temp[[feature], :]
                    
        # Wilks' L.
        if np.linalg.det(v_temp) == 0:
            epsilon = 1e-10 # или np.finfo(float).eps
            v_temp = v_temp + np.eye(v_temp.shape[0]) * epsilon
    
        wl_val = np.linalg.det(w_temp) / np.linalg.det(v_temp)
        if wl_val == 0:
            wl_val = 1e-10

        # степени свободы числителя
        deg_free_w = num_groups - 1

        # степени свободы знаменателя
        deg_free_v = num_samples - num_groups - w_temp.shape[1] + 1

        # F-value
        f_val = deg_free_v / deg_free_w * (wilks_temp / wl_val - 1.)
        
        # p-value
        p_val = st.f.sf(f_val, deg_free_w, deg_free_v)

        # поиск наибольшего F-value 
        # соответствующий ему индекс переменной и будет добавлен в модель
        if f_val > f_val_add and f_val > f_enter and wl_val < wilks_l:
            f_val_add = f_val
            wilks_l = wl_val
            p_val_add = p_val
            idx_add_first = feature
        
        # если нет подходящей переменной - действие для except  TypeError 
        if idx_add_first == None:
            return list_var_entered
            
    list_var_entered.append(idx_add_first)
    features.remove(idx_add_first)

    # степени свободы
    df1 = num_groups - 1
    df2 = num_samples - num_groups

    # набор переменных для записи в DF
    list_first_stat = [step, 
                       idx_add_first, 
                       '', 
                       wilks_l, 
                       df1, 
                       df2, 
                       f_val_add, 
                       df1, df2, 
                       p_val_add]

    # cохранение результатов в DF 
    # для введенных переменных
    df_vars_entered = pd.DataFrame(
        [list_first_stat],
        columns=[
            "Step", 
            "Entered", 
            "Removed", 
            "Wilks' L.", 
            "df1", 
            "df2", 
            "Statistic",
            "df1", 
            "df2", 
            "p-value"]
        )
    
    print(df_vars_entered.to_string(index=False))
    
    # добавление/удаление следующих переменных 
    while True:
        
        features.sort()
        step += 1
        wilks_add = None
        f_val_add = -np.inf
        idx_add = None

        # добавление
        for feature in features:
            
            list_var_entered.append(feature)
           
            w_temp = W[:, list_var_entered]
            w_temp = w_temp[list_var_entered, :]
            v_temp = V[:, list_var_entered]
            v_temp = v_temp[list_var_entered, :]

            w_temp_swp = symmetric_sweep(w_temp)
    
            # текущая Wilks' L.
            if np.linalg.det(v_temp) == 0:
                epsilon = 1e-10 # или np.finfo(float).eps
                v_temp = v_temp + np.eye(v_temp.shape[0]) * epsilon
            wl_val = np.linalg.det(w_temp) / np.linalg.det(v_temp)
            if wl_val == 0:
                wl_val = 1e-10

            # степени свободы
            deg_free_w = num_groups - 1
            deg_free_v = num_samples - num_groups - w_temp.shape[1] + 1
            
            # F для добавления
            f_val = deg_free_v / deg_free_w * (wilks_l / wl_val - 1.)

            # -----проверка мультиколлинеарности с помощью метрик Tolerance и Min Tolerance-----

            len_temp = len(list_var_entered)
            tol_list = list_var_entered.copy()
            
            if w_temp[len_temp - 1, len_temp - 1] != 0:

                tolerance = w_temp_swp[len_temp - 1, len_temp - 1] / w_temp[len_temp - 1, len_temp - 1]

                # инициализация минимальной tolerance
                min_tolerance = np.inf

                for item in list_var_entered:

                    # для добавляемого feature значение tolerance уже известно
                    if item == feature:
                        min_tol_item = tolerance
                    
                    else:
                    
                        # последний эл-т списка делаем первым
                        last_element = tol_list.pop()
                        tol_list.insert(0, last_element)
                        
                        w_temp = W[:, tol_list]
                        w_temp = w_temp[tol_list, :]

                        w_temp_swp = symmetric_sweep(w_temp)

                        min_tol_item = w_temp_swp[len_temp - 1, len_temp - 1] / w_temp[len_temp - 1, len_temp - 1]
                        
                    # print(item)
                    # print(min_tol_item)

                    if min_tol_item < min_tolerance:
                        min_tolerance = min_tol_item   

            else:
                tolerance = 0.
                min_tolerance = 0. 
            
            # ----------------------------------------//----------------------------------------

            list_var_entered.remove(feature)
            
            # условие включения переменной в модель
            if f_val > f_val_add and f_val > f_enter and wl_val < wilks_l and min_tolerance > 0.001:
                f_val_add = f_val
                wilks_add = wl_val
                idx_add = feature

        if idx_add == None:
            break
        
        list_var_entered.append(idx_add)
        wilks_l = wilks_add

        # RAO -статистика
        rao_df1, rao_df2, rao_f = rao_stat(
            list_var_entered, 
            num_groups, 
            num_samples, 
            wilks_l
            )

        # набор переменных для записи в DF
        list_add_stat = [step, 
                         idx_add, 
                         '', 
                         wilks_l, 
                         df1, 
                         df2, 
                         rao_f, 
                         rao_df1, 
                         rao_df2, 
                         p_val_add]

        # cохранение результатов в DF для удаленной переменной
        df_temp = pd.DataFrame(
            [list_add_stat],
            columns=["Step", 
                     "Entered", 
                     "Removed", 
                     "Wilks' L.", 
                     "df1", 
                     "df2", 
                     "Statistic", 
                     "df1", 
                     "df2", 
                     "p-value"]
            )
        
        print(df_temp.to_string(index=False))

        # Добавляем строку с новой переменной в результат
        df_vars_entered = pd.concat([df_vars_entered, df_temp], axis=0)

        features.remove(idx_add)

        # инициализация списка переменных для удаления
        list_var_del = list_var_entered.copy()

        # инициализация наименьшего f-value
        f_min = np.inf

        # инициализация индекса переменной для удаления 
        idx_del = None

        wilks_del = None

        # удаление
        for feature in list_var_entered:

            list_var_del.remove(feature)
            w_temp = W[:, list_var_del]
            w_temp = w_temp[list_var_del, :]
            v_temp = V[:, list_var_del]
            v_temp = v_temp[list_var_del, :]

            if np.linalg.det(v_temp) == 0:
                epsilon = 1e-10 # или np.finfo(float).eps
                v_temp = v_temp + np.eye(v_temp.shape[0]) * epsilon

            wl_val = np.linalg.det(w_temp) / np.linalg.det(v_temp)
            if wl_val == 0:
                wl_val = 1e-10

            deg_free_w = num_groups - 1
            deg_free_v = num_samples - num_groups - w_temp.shape[1]
            f_val = deg_free_v / deg_free_w * (wl_val / wilks_l - 1.)

            list_var_del.append(feature)

            # индекс переменной, где знначение f_val будет меньше f_del 
            # и наименьшее из всех с таким условием
            if f_val < f_del and f_val < f_min:
                f_min = f_val
                wilks_del = wl_val
                idx_del = feature
            
        if idx_del != None:

            step += 1

            list_var_entered.remove(idx_del)
            features.append(idx_del)
            wilks_l = wilks_del

            rao_df1, rao_df2, rao_f = rao_stat(
            list_var_entered, 
            num_groups, 
            num_samples, 
            wilks_l
            )

            list_del_stat = [step, 
                             '', 
                             idx_del, 
                             wilks_l, 
                             df1, 
                             df2, 
                             rao_f, 
                             rao_df1, 
                             rao_df2, 
                             p_val_add]

            # cохранение результатов в DF для удаленной переменной
            df_temp = pd.DataFrame(
                [list_del_stat],
                columns=["Step", 
                         "Entered", 
                         "Removed", 
                         "Wilks' L.", 
                         "df1", 
                         "df2", 
                         "Statistic", 
                         "df1", 
                         "df2", 
                         "p-value"]
                )
            
            print(df_temp.to_string(index=False))

            # Добавляем строку с новой переменной в результат
            df_vars_entered = pd.concat([df_vars_entered, df_temp], axis=0)

        if len(features) == 0:
            break

    if verbose:
        print('\nVARIABLES ENTERED/REMOVED:\n', df_vars_entered.to_string(index=False))

    return list_var_entered
