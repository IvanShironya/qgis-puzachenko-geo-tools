# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
import os
import glob

import importlib.util
import sys

# from memory_profiler import profile


class LDA():
    '''Линейный дискриминантный анализ'''

    def __init__(self, idx_features=None, target=None, idx_samples_feature = None): 
        '''
        idx_features: индексы переменных (список)
        target: лэйблы целевых значений (список)
        idx_samples_feature: индексы наблюдений (список)
        '''

        self.idx_features = idx_features
        self.target = target
        self.idx_samples_feature = idx_samples_feature

    def fit(self, X, y):
        '''Обучение (тренировка) модели на обучающей выборке'''

        self.X_ = X
        
        self.y_ = y

        self._compute_stats(X=X, y=y)

        return self
    
    # @profile
    def _compute_stats(self, X, y):
        '''Создание модели + статистика'''
        
        # целевыe значения (метки групп)
        self.groups_ = self.target

        # индексы независимых переменных по маске меток групп
        mask_indexes = np.isin(y, self.groups_)
        # независимые переменные
        X = X[mask_indexes, :]
        # целевые (зависимые, дискретные) переменные
        y = y[mask_indexes]

        # индексы переменных
        self.idx_features_ = self.idx_features

        # обновляем X (выборка по индексам переменных из STEPWISE)
        X = X[:, self.idx_features_]

        # количество строк и непрерывных переменных
        self.num_samples_, self.num_features_ = X.shape

        # количество групп
        self.num_groups_ = len(self.groups_)

        # индексы наблюдений
        self.idx_samples_feature_ = self.idx_samples_feature

        # пропорции групп
        # gr_proportions_list = []
        # for gr in self.groups_:
        #     gr_proportions_list.append(X[y == gr].shape[0] / X.shape[0])
        # gr_proportions = np.array(gr_proportions_list)
        gr_proportions = np.ones((self.num_groups_, )) / self.num_groups_

        # среднии по группам для переменных в анализе
        mean_vectors = []
        for gr in self.groups_:
            mean_vectors.append(np.nanmean(X[y == gr], axis=0))
        gr_mean = np.array(mean_vectors)

        # общая ковариация
        V = np.cov(X, ddof=1, rowvar=False)
        # V = np.ma.cov(np.ma.masked_invalid(X), ddof=1, rowvar=False)

        # ковариации по группам
        Sw = 0
        for gr in self.groups_:
            X_gr = X[y == gr]
            # Формула объединенной внутригрупповой ковариационной матрицы:
            # W = (n1 - 1)Sw1 + ... + (nk - 1)Swk / (n1 + ... + nk - n), где
            # n1, ..., nk - количество выборок (наблюдений) в группе 1, ..., k
            # Sw1, ..., Swk - ковариационные матрицы групп 1, ..., k
            # n - количество групп
            Sw += np.cov(X_gr, ddof=1, rowvar=False) * (X[y == gr].shape[0] - 1)
        W = Sw / (self.num_samples_ - self.num_groups_)

        #--------------------------------------------------------------------------
        # Объединенная корреляционная матрица по группам
        # std_deviations = np.sqrt(np.diag(W))
        # pooled_corr_matrix = W / np.outer(std_deviations, std_deviations)
        # # print(pooled_corr_matrix)
        # self.pooled_wcorr_ = pooled_corr_matrix
        #--------------------------------------------------------------------------

        # коэффициенты функции классификации и константы
        self._compute_coeff(W=W,gr_m=gr_mean, gr_p=gr_proportions)

        # сохраняем
        self.tcov_ = V
        self.wcov_ = W
        self.gr_proportions_ = gr_proportions
        self.gr_mean_ = gr_mean

        self.model_ = 'lda'
    
    # @profile
    def _compute_coeff(self, W, gr_m, gr_p):
        '''Коэффициенты функции классификации'''

        # обратная к W
        # inv_W = np.linalg.inv(W)
        try:
            # print("Matrix W:", W)
            rank = np.linalg.matrix_rank(W)
            # print("Rank W:", rank)
            # print("Matrix W shape:", W.shape)
            inv_W = np.linalg.inv(W)
        except np.linalg.LinAlgError as e:
            # inv_W = np.linalg.pinv(W) # использование псевдообратной матрицы
            
            # регуляризация (добавляем небольшое значение к диагонали матрицы)
            epsilon = 1e-10 # или np.finfo(float).eps
            W = W + np.eye(W.shape[0]) * epsilon
            inv_W = np.linalg.inv(W)
            print("ERROR: ", e)
            print("Regularization method is used to avoid singularity...")

        # коэффициенты функции классификации
        coeff = pd.DataFrame(inv_W @ gr_m.T, index=self.idx_features_, columns=self.groups_)

        # константы
        a = np.log(gr_p)
        b = gr_m @ inv_W
        b = 0.5 * b @ gr_m.T
        c = a - np.diag(b)

        c_for_df = np.array([c[k] for k in range(self.num_groups_)])
        c_for_df = c_for_df.reshape((1, self.num_groups_))
        constant = pd.DataFrame(c_for_df, index=['CONSTANT'], columns=self.groups_)
        self.coeff_ = coeff
        self.constant_ = constant
    
    # @profile
    def compute_decision(self, X):
        '''Дискриминантные баллы'''

        # scores = np.zeros((X.shape[0], self.num_groups_))
        # for gr in list(range(self.num_groups_)):
        #     # из X  вычитаем среднее группы
        #     x_sub_gr_m =  X - self.gr_mean_[gr, :]

        #     # ковариационная матрица группы
        #     gr_cov = np.cov(X[y == self.groups_[gr]], ddof=1, rowvar=False)
            
        #     mt = (x_sub_gr_m @ np.linalg.inv(gr_cov)) @ x_sub_gr_m.T

        #     scores_gr = np.log(self.gr_proportions_[gr]) - (1 / 2) * np.log(np.linalg.det(gr_cov)) - (1 / 2) * np.diag(mt)
            
        #     scores[:, gr] = scores_gr

        decision = (X @ self.coeff_.to_numpy()) + self.constant_.to_numpy()
        
        return decision
    
    # @profile
    def compute_probabilities(self, X):
        '''Вероятности'''

        # решение
        scores = self.compute_decision(X)

        # заменим значения NaN на -inf
        scores = np.nan_to_num(scores, nan=-np.inf)

        # максимальный элемент по каждой строке массива scores
        max_scores = np.nanmax(scores, axis=1, keepdims=True)

        # заменим элементы -inf в max_scores на NaN
        max_scores[max_scores == -np.inf] = np.nan

        # вычитаем максимальный элемент каждой строки из каждого элемента этой строке
        centered_scores = scores - max_scores

        # экспоненты
        exp_scores = np.exp(centered_scores)

        # нормализовав каждую строку, разделив на сумму ее элементов
        # получаем вероятности
        sum_exp_scores = np.nansum(exp_scores, axis=1)
        probabilities = exp_scores / sum_exp_scores[:, np.newaxis]
        
        return probabilities
    
    # @profile
    def predict(self, X):
        '''Прогнозирование значений'''
        
        probabilities = self.compute_probabilities(X)
        #predict = np.array([np.array(self.groups_)[np.argmax(probabilities, axis=1)]]).T
        
        # индекс максимального элемента, отличного от NaN, в каждой строке вероятностей
        # max_idx = []
        # for row in probabilities:
        #     non_nan_indices = np.where(~np.isnan(row))[0]
        #     if len(non_nan_indices) == 0:
        #         max_idx.append(0)
        #     else:
        #         max_idx.append(np.nanargmax(row))
        # max_idx = np.array(max_idx)

        # индексы максимальных значений по строкам массива probabilities
        # max_idx = np.nanargmax(probabilities, axis=1)
    
        # заменяем индексы на 0, где все значения в строке имеют значение NaN
        # max_idx = np.where(np.isnan(probabilities).all(axis=1), 0, max_idx)

        # при обнаружении срезов, состоящих из всех чисел NaN, возникает ошибка ValueError
        try:
            # индексы максимальных значений по строкам массива probabilities
            max_idx = np.nanargmax(probabilities, axis=1)

        except ValueError:

            # заменяем индексы на 0, где все значения в строке имеют значение NaN
            max_idx = np.nanargmax(np.nan_to_num(probabilities), axis=1)

        # соответствующее имя группы на основе индекса
        predict = np.array([np.array(self.groups_)[max_idx]], dtype=float).T

        # заменим значения в прогнозе на NaN, 
        # где соответствующие строки в вероятностях содержат NaN
        nan_rows = np.isnan(probabilities).any(axis=1)
        np.putmask(predict, nan_rows, np.nan)

        return predict


class CDA():
    '''Канонический дискриминантный анализ'''

    def __init__(self, idx_features=None, target=None, idx_samples_feature = None): 
        '''
        idx_features: индексы переменных
        target: лэйблы целевых значений
        idx_samples_feature: индексы наблюдений
        '''

        self.idx_features = idx_features
        self.target = target
        self.idx_samples_feature = idx_samples_feature

    def fit(self, X, y):
        '''Обучение (тренировка) модели на обучающей выборке'''

        self.X_ = X
        
        self.y_ = y

        self._compute_stats(X=X, y=y)

        return self
    
    # @profile
    def _compute_stats(self, X, y):
        '''Создание модели + статистика'''

       # целевыe значения (метки групп)
        self.groups_ = self.target

        # индексы независимых переменных по маске меток групп
        mask_indexes = np.isin(y, self.groups_)
        # независимые переменные
        X = X[mask_indexes, :]
        # целевые (зависимые, дискретные) переменные
        y = y[mask_indexes]

        # индексы переменных
        self.idx_features_ = self.idx_features

        # обновляем X (выборка по индексам переменных из STEPWISE)
        X = X[:, self.idx_features_]

        # количество строк и непрерывных переменных
        self.num_samples_, self.num_features_ = X.shape

        # количество групп
        self.num_groups_ = len(self.groups_)

        # средние значения X
        X_means = np.mean(X, axis=0)

        # пропорции групп
        gr_proportions_list = []
        for gr in self.groups_:
            gr_proportions_list.append(X[y == gr].shape[0] / X.shape[0])
        gr_proportions = np.array(gr_proportions_list)
        
        # среднии по группам для переменных в анализе
        mean_vectors = []
        for gr in self.groups_:
            mean_vectors.append(np.nanmean(X[y == gr], axis=0))
        gr_mean = np.array(mean_vectors)

        # общая ковариация
        V = np.cov(X, ddof=0, rowvar=False)

        # ----------коэффициенты канонической дискриминантной функции----------

        # матрица канонической корреляции
        C_list = [] 
        for gr in list(range(self.num_groups_)):
            C_temp = np.sqrt(gr_proportions[gr]) * (gr_mean[gr] - X_means)
            C_list.append(C_temp)
        C = np.array(C_list).T

        # диаганолизация
        EE = (C.T @ np.linalg.inv(V)) @ C

        # собственные значения и собственные вектора
        evals, evecs = np.linalg.eig(EE)

        # сортируем по убыванию собственные значения и собственные вектора
        idx = np.argsort(evals)[::-1]
        evecs = evecs[:, idx]
        evals = evals[idx]
        
        # ищем оси k − 1 канонических координат, где k — число групп
        evals = evals[:self.num_groups_ - 1]
        evecs = evecs[:, :self.num_groups_ - 1]

        # бета-вектор
        beta_vec = (np.linalg.inv(V) @ C) @ evecs

        # коэффициенты (нестандартизированные) канонической дискриминантной функции
        arr_can_coeff = np.apply_along_axis(
            func1d=lambda x : x * np.sqrt(
            (self.num_samples_ - self.num_groups_) / (self.num_samples_ * evals * (1. - evals))),
            arr=beta_vec, axis=1)

        # константы
        arr_can_constant = -arr_can_coeff.T @ X_means

        # коэффициенты канонической дискриминантной функции для вывода в pandas
        canonical_coeff = pd.DataFrame(
            arr_can_coeff, 
            index=self.idx_features_, 
            columns=list(range(1, self.num_groups_))
            )
        
        # константы для вывода в pandas
        for_df = np.array([arr_can_constant[k] for k in range(self.num_groups_ - 1)])
        for_df = for_df.reshape((1, self.num_groups_ - 1))
        canonical_constant = pd.DataFrame(for_df, index=['CONSTANT'], columns=list(range(1, self.num_groups_)))

        self.canonical_coeff_ = canonical_coeff
        self.canonical_constant_ = canonical_constant

        # -------------------------------///-----------------------------------

        # --------------------------Матрица структуры--------------------------

        # канонические переменные (координаты)
        canonical_vars = self.compute_canonical_coords(X)

        # среднии по группам для канонических переменных
        can_mean_vectors = []
        for gr in self.groups_:
            can_mean_vectors.append(np.mean(canonical_vars[y == gr], axis=0))
        gr_mean_can = np.array(can_mean_vectors)
        
        # центрируем канонические переменные по группам (вычитаем среднее по группам)
        can_centered = canonical_vars
        for gr in self.groups_:
            can_centered[y == gr] -= gr_mean_can[self.groups_.index(gr)]
        
        # центрируем независимые переменные
        X_centered = X
        for gr in self.groups_:
            X_centered[y == gr] -= gr_mean[self.groups_.index(gr)]
        
        # объединенные внутригрупповые корреляции между дискриминантными переменными 
        # и стандартизированными каноническими дискриминантными функциями
        W_corr = np.transpose(np.corrcoef(
            x=can_centered, 
            y=X_centered, 
            rowvar=False)
            [:self.num_groups_ - 1, self.num_groups_ - 1:])
        
        # матрица структуры DF
        W_corr = pd.DataFrame(
            W_corr, 
            index=self.idx_features_, 
            columns=list(range(1, self.num_groups_))
            )
        
        # сортируем DF по последнему столбцу в порядке убывания (по модулю)
        #W_corr = W_corr.sort_values(by=W_corr.columns[-1], ascending=False)
        W_corr = W_corr.loc[W_corr.iloc[:, -1].abs().sort_values(ascending=False).index]
        
        # матрица структуры DF
        self.W_corr_ = W_corr

        # -------------------------------///-----------------------------------

        self.model_ = 'cda'

    # @profile
    def compute_canonical_coords(self, X):
        '''Дискриминантные баллы (канонические координаты)'''
        
        canonical_coords = X @ self.canonical_coeff_.to_numpy() + self.canonical_constant_.to_numpy()
        
        return canonical_coords
        

class STEPWISE():
    '''Пошаговые методы отбора переменных для модели'''

    def __init__(self,
                 method="stepwise",
                 method_stepwise=None,
                 f_enter=None,
                 f_remove=None,
                 model_train = False,
                 verbose = True):
        
        self.method_stepwise = method_stepwise
        self.method = method
        self.f_enter = f_enter
        self.f_remove = f_remove
        self.model_train = model_train
        self.verbose = verbose

    def fit(self, class_instance):
        '''
        class_instance : экземпляр класса LDA
        '''

        self._compute_stats(class_instance)
        
        return self
    
    # @profile
    def _compute_stepwise(self, class_instance):
        ''''''

        # используемые матрицы V и W
        V = (
            (class_instance.num_samples_ - 1) / class_instance.num_samples_
            ) * class_instance.tcov_
       
        W = (
            (class_instance.num_samples_ - class_instance.num_groups_) / class_instance.num_samples_
            ) * class_instance.wcov_

        # список переменных для отбора
        idx_select = class_instance.idx_features_

        # путь к исполняемому файлу (папка с плагином)
        plugin_folder_path = os.path.dirname(os.path.abspath(__file__))
        # путь к папке methods в папке плагином
        other_folder_path = os.path.join(plugin_folder_path, 'methods')
        # путь к файлам всех модулей
        modules = glob.glob('%s/*.py' % other_folder_path)
        #print(modules)
        #module_name = "Wilks' lambda"
        path_module = [element for element in modules if self.method_stepwise in element]
        #print(path_module)
        spec = importlib.util.spec_from_file_location(self.method_stepwise, path_module[0])
        foo = importlib.util.module_from_spec(spec)
        sys.modules[self.method_stepwise] = foo
        spec.loader.exec_module(foo)
        result_forward = foo.method(
            W=W, 
            V=V,
            features=idx_select, 
            num_groups=class_instance.num_groups_,
            num_samples=class_instance.num_samples_, 
            f_enter=self.f_enter,
            f_del=self.f_remove, 
            verbose=self.verbose) 

        return result_forward

    # @profile
    def _compute_stats(self, class_instance):
        
        if self.method == 'forward':
            vars_add = self._compute_forward(class_instance=class_instance)
        elif self.method == 'backward':
            vars_add = self._compute_backward(class_instance=class_instance)
        elif self.method == 'stepwise':
            vars_add = self._compute_stepwise(class_instance=class_instance)

        idx_features_add = vars_add
        idx_features_add.sort()
        
        # обучение модели
        if self.model_train:
            # новые переменные для модели
            if class_instance.model_ == 'lda':
                model = LDA(
                    idx_features=idx_features_add,
                    target=class_instance.groups_,
                    idx_samples_feature=class_instance.idx_samples_feature_
                    ).fit(class_instance.X_, class_instance.y_)
                self.train_model_ = model

        self.vars_add_ = vars_add
        self.idx_features_add_ = idx_features_add
