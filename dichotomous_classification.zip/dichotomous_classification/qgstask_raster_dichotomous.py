# -*- coding: utf-8 -*-

"""
/***************************************************************************
QgsTaskRasterDichotomous
 
                                 A QGIS plugin
 Dichotomous k-means Classification
                             -------------------
        changed              : 2026-08-14
        begin                : 2025-10-07
        version              : 1.1
        git sha              : $Format:%H$
        copyright            : (C) 2025-2026 by I. Shironya
        email                : ivan.shironya@gmail.com
 ***************************************************************************/
"""


from qgis.core import QgsTask

from osgeo import gdal, osr
import numpy as np
from scipy.spatial.distance import cdist
from numpy.linalg import LinAlgError

from .task_utils import TaskSignals


class QgsTaskRasterDichotomous(QgsTask):

    def __init__(
            self, 
            raster_source, 
            selected_bands, 
            init_method="Synthetic vectors", 
            metric="Euclidean", 
            levels=1,
            max_iter=100,
            tol=1e-7,
            min_cluster_size=2,
            description: str = "Compute Raster Dichotomous Task"
        ):

        super().__init__(description, QgsTask.CanCancel)
        self.signals = TaskSignals()
        self.raster_source = raster_source
        self.selected_bands = selected_bands
        self.init_method = init_method
        self.metric = metric
        self.levels = levels
        self.max_iter = max_iter
        self.tol = tol
        self.min_cluster_size = min_cluster_size

        # --- новый буфер логов ---
        self._log_messages = []

        self._dichotomous_result = None # массив дихотомических меток, чтобы передать в finished()
        self._report = None # репорт дихотомии, чтобы передать в finished()
        self._html_report = []  # список словарей для структурированного отчета
            
    def _log(self, message, *args):
        """
        Безопасный логгер: принимает любое количество аргументов.
        Первый — основное сообщение, остальные игнорируются.
        """

        try:
            msg = str(message)
        except Exception:
            msg = repr(message)

        self._log_messages.append(msg)

    def _get_log_report(self):
        """Возвращает весь лог как одну строку."""

        return "\n".join(self._log_messages)

    def _add_html_report_entry(self, cluster_id, level, init_centroid, final_centroid, size, feature_contrib=None):
        """
        Добавляет запись о кластере в структурированный отчет.
        """

        def _to_1d_list(x):
            if isinstance(x, np.ndarray):
                return np.asarray(x).reshape(-1).tolist()
            if isinstance(x, list):
                return np.asarray(x).reshape(-1).tolist()
            return x
    
        entry = {
            "level": int(level),
            "cluster_id": int(cluster_id),
            "init_centroid": _to_1d_list(init_centroid),
            "final_centroid": _to_1d_list(final_centroid),
            "size": int(size),
        }

        # Опционально: вклад признаков
        if feature_contrib is not None:
            mean_delta = feature_contrib.get("mean_delta")
            entry["mean_feature_delta"] = (
                np.asarray(mean_delta).reshape(-1).tolist()
                if mean_delta is not None
                else None
            )
            entry["dominant_feature"] = feature_contrib.get("dominant_component")

        self._html_report.append(entry)

    def _euclidean_distances_to_point(self, point, data):
        """Вспомогательная функция для расстояний к одной точке (возвращают вектор длины N)."""

        # data: (N, D), point: (D,)
        # возвращаем np.linalg.norm(data - point, axis=1)
        return np.linalg.norm(data - point, axis=1)

    def _mahalanobis_distances_to_point(self, point, data, cov_inv):
        """Вспомогательная функция для расстояний к одной точке (возвращают вектор длины N)."""

        # вычисляем sqrt((x - p).T @ cov_inv @ (x - p)) для всех x
        diff = data - point  # (N,D)
        tmp = diff.dot(cov_inv)  # (N,D)
        dist2 = np.einsum('ij,ij->i', tmp, diff)  # (N,)
        # численные погрешности: отрицательные ~ 0
        dist2[dist2 < 0] = 0.0
        return np.sqrt(dist2)

    def _centroid_metric_score(self, centroid, metric="Euclidean", cov_inv=None):
        """Score центроида для сортировки: Евклидова норма или Фишер норма."""

        if metric == "Euclidean":
            return np.linalg.norm(centroid)
        else:
            if cov_inv is None:
                return np.linalg.norm(centroid)
            tmp = centroid.dot(cov_inv)
            val = float(np.sqrt(np.dot(tmp, centroid)))
            return val

    def _initialization_centroids(self, data, cov_inv=None, method="Synthetic vectors", metric="Euclidean"):
        """
        Выбор начальных центроидов.
        - Для небольших выборок (<= max_full) можно осмысленно посчитать полную попарную матрицу.
        - Для больших данных используем farthest-point heuristic с несколькими рестартами.
        """

        # Synthetic vectors: min и max в каждом канале
        if method == "Synthetic vectors":
            min_vec = np.min(data, axis=0)
            max_vec = np.max(data, axis=0)

            return np.vstack([min_vec, max_vec])
        
        # Most distant: стараемся найти пару наиболее далёких точек по выбранной метрике
        elif method == "The most distant by metric":
            N = data.shape[0]
            # порог для "полной" матрицы попарных расстояний (настраивается под доступную память)
            max_full = 10000  # если N <= 10000 можно безопасно делать cdist (10000^2 ~ 100M чисел или ~ 0.8 GB RAM)
            
            if N <= max_full:
                if metric == "Euclidean":
                    dists = cdist(data, data, metric="euclidean")
                else:
                    # Для метрики Фишера (расстояния Махаланобиса с обратной ковариационной матрицей)
                    dists = cdist(data, data, metric="mahalanobis", VI=cov_inv)

                i, j = np.unravel_index(np.argmax(dists), dists.shape)

                return np.vstack([data[i], data[j]])
            else:
                # Для больших данных — жадный farthest-point (O(k * N) времени, O(N) памяти)
                rng = np.random.default_rng()
                restarts = 10  # число рестартов (можно уменьшить/увеличить: 1-2 низкая точность, 5 хорошая, 10 отличная, >10 выйгрыш <1% но время х20)
                best_pair = ( -1.0, None, None )  # (distance, idx_i, idx_j)

                for _ in range(restarts):
                    seed_idx = int(rng.integers(0, N))
                    # 1) найти farthest от seed_idx
                    if metric == "Euclidean":
                        d = self._euclidean_distances_to_point(data[seed_idx], data)
                    else:
                        d = self._mahalanobis_distances_to_point(data[seed_idx], data, cov_inv)
                    i = int(np.argmax(d))

                    # 2) найти farthest от i
                    if metric == "Euclidean":
                        d2 = self._euclidean_distances_to_point(data[i], data)
                    else:
                        d2 = self._mahalanobis_distances_to_point(data[i], data, cov_inv)
                    j = int(np.argmax(d2))
                    pair_dist = float(d2[j])

                    if pair_dist > best_pair[0]:
                        best_pair = (pair_dist, i, j)
                
                i, j = best_pair[1], best_pair[2]

                return np.vstack([data[i], data[j]])
        
        else:
            raise ValueError("Unknown initialization method!")
    
    def _compute_distance_feature_contributions(
        self,
        X,
        labels,
        centroids,
        metric="Euclidean",
        cov_inv=None
    ):

        """
        Вычисляет дискриминативный вклад признаков в решение
        о принадлежности к кластеру 0 или 1.

        Для каждого признака j считается:
            Δ_j = (x_j - μ1_j)^2 - (x_j - μ0_j)^2

        Интерпретация:
            Δ_j > 0  → признак толкает в кластер 0
            Δ_j < 0  → признак толкает в кластер 1

        Возвращает по каждому кластеру (0 и 1):
        {
            k: {
                'mean_delta': array(D),
                'dominant_component': int
            }
        }
        """

        mu0, mu1 = centroids

        if metric == "Fisher":
            if cov_inv is None:
                raise ValueError("Covariance matrix is required for Fisher metric")

            diff0 = X - mu0
            diff1 = X - mu1

            # покомпонентный вклад в квадратичную форму
            c0 = diff0 * (cov_inv @ diff0.T).T
            c1 = diff1 * (cov_inv @ diff1.T).T
        else:
            # Евклидово расстояние
            c0 = (X - mu0) ** 2
            c1 = (X - mu1) ** 2

        # ДИСКРИМИНАТИВНАЯ разность
        delta = c1 - c0

        results = {}

        for k in (0, 1):
            mask = labels == k
            if not np.any(mask):
                continue

            mean_delta = delta[mask].mean(axis=0)

            dominant = int(np.argmax(np.abs(mean_delta)))

            results[k] = {
                "mean_delta": mean_delta,
                "dominant_component": dominant
            }

        return results

    def _kmeans_2(
        self, 
        data,
        metric="Euclidean",
        cov_inv=None,
        init_method="Synthetic vectors",
        max_iter=100,
        tol=1e-4,
        level=None,
        cluster_id=None
    ):
        """
        data: (N, D), без NaN
        возвращает: labels (N, dtype=np.uint32), centroids (2, D)
        Формирует структурированный отчет для HTML.
        """
        
        if data.shape[0] < 2:
            self._log(f"[INFO][LEVEL {level}] Cluster {cluster_id} has <2 samples — marked as leaf.")
            labels = np.zeros(data.shape[0], dtype=np.uint32)
            centroid = data.mean(axis=0, keepdims=True)

            # Добавляем в структурированный отчет
            self._add_html_report_entry(
                cluster_id=cluster_id,
                level=level,
                init_centroid=centroid.copy(),
                final_centroid=centroid.copy(),
                size=data.shape[0]
            )

            return labels, np.vstack([centroid, centroid])
        
        # Проверка дисперсии — если данные почти одинаковые
        if np.allclose(np.var(data, axis=0), 0, atol=1e-8):
            self._log(f"[INFO][LEVEL {level}] Cluster {cluster_id} variance ≈ 0 — marked as leaf.")
            labels = np.zeros(data.shape[0], dtype=np.uint32)
            centroid = data.mean(axis=0, keepdims=True)

            # Добавляем в структурированный отчет
            self._add_html_report_entry(
                cluster_id=cluster_id,
                level=level,
                init_centroid=centroid.copy(),
                final_centroid=centroid.copy(),
                size=data.shape[0]
            )

            return labels, np.vstack([centroid, centroid])

        n = data.shape[0]
        self._log(f"\n[LEVEL {level}] Starting k-means for Cluster {cluster_id} with {n} pixels...")

        # --- Инициализация центроидов ---
        centroids = self._initialization_centroids(data, cov_inv, method=init_method, metric=metric)
        init_centroids = centroids.copy()  # Сохраняем для отчета
        self._log(f"[LEVEL {level}] Initial centroids (Cluster {cluster_id}):\n{centroids}") 

        for it in range(max_iter):
            # расстояния до двух центроидов (N, )
            if metric == "Euclidean":
                d0 = np.linalg.norm(data - centroids[0], axis=1)
                d1 = np.linalg.norm(data - centroids[1], axis=1)
            else:
                # self._mahalanobis_distances_to_point возвращает (N,) float
                d0 = self._mahalanobis_distances_to_point(centroids[0], data, cov_inv)
                d1 = self._mahalanobis_distances_to_point(centroids[1], data, cov_inv)

            # Формируем матрицу расстояний (N, 2) и выбираем минимальное значение по каждой строке
            labels = np.argmin(np.vstack([d0, d1]).T, axis=1)   # 0 или 1

            # Проверка на пустые кластеры
            counts = np.bincount(labels, minlength=2)
            if counts[0] == 0 or counts[1] == 0:
                # это критическая ситуация — лучше сообщить и прервать
                empty_idx = 0 if counts[0] == 0 else 1
                self._log(f"[INFO][LEVEL {level}] Cluster {empty_idx} is empty during kmeans — stop splitting.")
                # Просто возвращаем текущие центроиды и выходим
                labels[:] = 0
                return labels.astype(np.uint32), centroids

            # пересчёт центроидов (безопасно)
            new_centroids = np.vstack([
                data[labels == 0].mean(axis=0),
                data[labels == 1].mean(axis=0)
            ])

            shift = np.linalg.norm(new_centroids - centroids)
            if np.isnan(shift):
                raise ValueError(f"[ERROR][LEVEL {level}] NaN detected in centroid shift; numerical issue.")

            self._log(f"[LEVEL {level}] Iteration {it + 1}: centroid shift = {shift:.10f}")

            if shift < tol:
                self._log(f"[LEVEL {level}] Converged after {it + 1} iterations (shift < {tol})")
                centroids = new_centroids
                break

            centroids = new_centroids
        
        # =================================================================
        # БЛОК: Логирование ДО сортировки
        # =================================================================
        
        self._log(f"\n[LEVEL {level}] === BEFORE SORTING (Cluster {cluster_id}) ===")
        self._log(f"[LEVEL {level}] Centroid[0] = {centroids[0]}")
        self._log(f"[LEVEL {level}] Centroid[1] = {centroids[1]}")
        
        # Вычисляем scores для НЕСОРТИРОВАННЫХ центроидов
        score_0_before = self._centroid_metric_score(centroids[0], metric, cov_inv)
        score_1_before = self._centroid_metric_score(centroids[1], metric, cov_inv)
        
        self._log(f"[LEVEL {level}] Score[0] = {score_0_before:.6f}")
        self._log(f"[LEVEL {level}] Score[1] = {score_1_before:.6f}")
        
        # Подсчёт размеров кластеров ДО сортировки
        count_0_before = np.sum(labels == 0)
        count_1_before = np.sum(labels == 1)
        self._log(f"[LEVEL {level}] Cluster[0] size = {count_0_before} pixels")
        self._log(f"[LEVEL {level}] Cluster[1] size = {count_1_before} pixels")
        
        # =================================================================
        # БЛОК СОРТИРОВКИ
        # =================================================================
        
        # Вычисляем метрики для сортировки
        scores = np.array([score_0_before, score_1_before])
        
        # Сортируем индексы по возрастанию метрики
        sorted_indices = np.argsort(scores)
        
        # Переупорядочиваем центроиды
        centroids = centroids[sorted_indices]
        
        # КРИТИЧЕСКИ ВАЖНО: переназначаем метки согласно новому порядку
        # Создаём mapping старых меток на новые
        label_mapping = np.empty(2, dtype=np.uint32)
        label_mapping[sorted_indices[0]] = 0
        label_mapping[sorted_indices[1]] = 1
        
        # Применяем mapping к меткам
        labels = label_mapping[labels]

        # вклад компонент
        feature_contrib = self._compute_distance_feature_contributions(
            data,
            labels,
            centroids,
            metric=self.metric,
            cov_inv=cov_inv
        )

        # --- Добавление в структурированный отчет ---
        for c in (0, 1):
            cluster_size = np.sum(labels == c)

            fc = None
            if feature_contrib is not None and c in feature_contrib:
                fc = feature_contrib[c]

            self._add_html_report_entry(
                cluster_id=cluster_id * 2 + c if cluster_id is not None else c,
                level=level,
                init_centroid=init_centroids[c],
                final_centroid=centroids[c],
                size=cluster_size,
                feature_contrib=fc
            )
        
        # =================================================================
        # БЛОК: Логирование ПОСЛЕ сортировки
        # =================================================================
        
        self._log(f"\n[LEVEL {level}] === AFTER SORTING (Cluster {cluster_id}) ===")
        
        # Показываем, какая перестановка произошла
        if sorted_indices[0] == 0 and sorted_indices[1] == 1:
            self._log(f"[LEVEL {level}] No reordering needed (already sorted)")
        else:
            self._log(f"[LEVEL {level}] Reordered: old[{sorted_indices[0]}]→new[0], old[{sorted_indices[1]}]→new[1]")
        
        self._log(f"[LEVEL {level}] Centroid[0] = {centroids[0]}")
        self._log(f"[LEVEL {level}] Centroid[1] = {centroids[1]}")
        
        # Пересчитываем scores для отсортированных центроидов
        score_0_after = self._centroid_metric_score(centroids[0], metric, cov_inv)
        score_1_after = self._centroid_metric_score(centroids[1], metric, cov_inv)
        
        self._log(f"[LEVEL {level}] Score[0] = {score_0_after:.6f} (sorted)")
        self._log(f"[LEVEL {level}] Score[1] = {score_1_after:.6f} (sorted)")
        
        # Подсчёт размеров кластеров ПОСЛЕ сортировки
        count_0_after = np.sum(labels == 0)
        count_1_after = np.sum(labels == 1)
        self._log(f"[LEVEL {level}] Cluster[0] size = {count_0_after} pixels")
        self._log(f"[LEVEL {level}] Cluster[1] size = {count_1_after} pixels")

        # Сравнительная таблица
        self._log(f"\n[LEVEL {level}] === COMPARISON TABLE ===")
        self._log(f"{'Metric':<15} | {'Before':<20} | {'After':<20}")
        self._log(f"{'-'*15}-+-{'-'*20}-+-{'-'*20}")
        self._log(f"{'Score[0]':<15} | {score_0_before:<20.6f} | {score_0_after:<20.6f}")
        self._log(f"{'Score[1]':<15} | {score_1_before:<20.6f} | {score_1_after:<20.6f}")
        self._log(f"{'Size[0]':<15} | {count_0_before:<20} | {count_0_after:<20}")
        self._log(f"{'Size[1]':<15} | {count_1_before:<20} | {count_1_after:<20}")
        
        # Проверка: scores должны быть в порядке возрастания
        if score_0_after <= score_1_after:
            self._log(f"\n[LEVEL {level}] ✓ Scores are correctly ordered (ascending)")
        else:
            self._log(f"\n[LEVEL {level}] ✗ WARNING: Scores not in ascending order!")
        
        self._log(f"[LEVEL {level}] Cluster {cluster_id} completed.\n")
    
        # =================================================================

        return labels.astype(np.uint32), centroids.copy()

    def _total_clusters(self, levels):
        """Общее количество кластеров на всех уровнях."""        

        return sum(2**i for i in range(1, levels + 1))
    
    def _dichotomic_kmeans(self, data,
                        levels=1,
                        metric="Euclidean",
                        cov_inv=None,
                        init_method="Synthetic vectors",
                        max_iter=100,
                        tol=1e-4,
                        level=1,
                        prefix=0):
        """
        Дихотомический k-means с глобальным прогрессом.
        data: (N, D) без NaN
        levels: 1..8
        Возврат: labels_all (N, levels), dtype=np.uint32
        """

        total = self._total_clusters(levels)

        # Инициализация глобального счетчика прогресса при первом вызове
        if level == 1 and not hasattr(self, "_global_progress_counter"):
            self._global_progress_counter = 0
            self._log(f"=== DICHOTOMIC START: total clusters to process = {total} ===")

        self._log(f"\n=== DICHOTOMIC LEVEL {level} START ===")
        self._log(f"Data size: {data.shape[0]} pixels | Prefix: {prefix}")

        N = data.shape[0]
        labels_all = np.zeros((N, levels), dtype=np.uint32)

        # --- Шаг 1: двухкластерный K-means ---
        try:
            labels, centroids = self._kmeans_2(
                data,
                metric=metric,
                cov_inv=cov_inv,
                init_method=init_method,
                max_iter=max_iter,
                tol=tol,
                level=level,
                cluster_id=prefix
            )
        except Exception as e:
            # Если внутри _kmeans_2 всё-таки произошло что-то критичное (не пустой кластер, а ошибка данных)
            self._log(f"[EXCEPTION][LEVEL {level}] {e}")
            # Прекращаем деление — всё помечаем одним кластером
            labels = np.zeros(data.shape[0], dtype=np.uint32)
            centroids = np.vstack([data.mean(axis=0), data.mean(axis=0)])

        # сохраняем метки текущего уровня (0/1) + сдвиг prefix*2 для глобальной нумерации
        # labels_all[:, level - 1] = (labels.astype(np.uint32) + np.uint32(prefix * 2))

        # Определяем ID двух возможных дочерних классов.
        #
        # На первом уровне:
        #   root -> 0, 1
        #
        # На следующих уровнях:
        #   parent -> parent, parent + 2^(level-1)
        #
        # Например:
        #   level 2: 0 -> 0, 2
        #            1 -> 1, 3
        #
        #   level 3: 0 -> 0, 4
        #            1 -> 1, 5
        #            2 -> 2, 6
        #            3 -> 3, 7

        if level == 1:
            current_child_labels = np.array(
                [0, 1],
                dtype=np.uint32
            )
        else:
            offset = 2 ** (level - 1)

            current_child_labels = np.array(
                [prefix, prefix + offset],
                dtype=np.uint32
            )

        self._log(
            f"[DEBUG] LEVEL {level}, PREFIX {prefix}: "
            f"child_labels={current_child_labels.tolist()}"
        )

        # Записываем результаты текущего уровня.
        labels_all[:, level - 1] = current_child_labels[labels]

        # --- Шаг 2: если достигнут последний уровень — выходим ---
        if level == levels:
            self._global_progress_counter += 1
            progress = int((self._global_progress_counter / total) * 100)
            self.signals.progress_signal.emit(progress)
            self.signals.progress_status.emit(f"Progress status: processing level {level}, cluster {prefix} (leaf, final level)")
            self._log(f"=== DICHOTOMIC LEVEL {level} END (leaf level) ===\n")
            return labels_all

        # --- Шаг 3: обрабатываем подкластеры ---
        for c in (0, 1):
            idx = np.where(labels == c)[0]
            cluster_size = idx.size

            # ID уже был назначен выше в current_child_labels.
            # Здесь повторно ID НЕ создаём.
            current_label = int(current_child_labels[c])

            # --- Проверки на пустые/малые кластеры ---
            if cluster_size == 0:
                # (a) Если кластер пустой — просто пропускаем
                self._log(f"[INFO] Cluster {current_label} empty — skipped.")
                continue

            # (b) Если в кластере <2 пикселей или нет уникальных (однородные) — считаем его "листом"
            unique_rows = np.unique(data[idx], axis=0)
            if cluster_size < self.min_cluster_size or unique_rows.shape[0] < 2:
                self._log(f"[INFO] Cluster {current_label} marked as leaf (too small or identical).")
                labels_all[idx, level - 1:] = np.uint32(current_label)

                # Обновляем прогресс
                self._global_progress_counter += 1
                progress = int((self._global_progress_counter / total) * 100)
                self.signals.progress_signal.emit(progress)
                self.signals.progress_status.emit(f"Progress status: processing level {level}, cluster {current_label} (leaf)")
                continue

            # --- Шаг 4: рекурсивно обрабатываем подкластер ---
            self._global_progress_counter += 1
            progress = int((self._global_progress_counter / total) * 100)
            self.signals.progress_signal.emit(progress)
            self.signals.progress_status.emit(f"Progress status: processing level {level}, cluster {current_label}...")

            # ДИАГНОСТИКА: проверяем, какой ID реально передаём
            # в следующий уровень рекурсии.
            self._log(
                f"[DEBUG] RECURSE: "
                f"level={level} -> {level + 1}, "
                f"cluster={c}, "
                f"current_label={current_label}, "
                f"prefix={current_label}, "
                f"size={cluster_size}"
            )

            # рекурсивное разбиение
            sub_labels = self._dichotomic_kmeans(
                data[idx],
                levels=levels,
                metric=metric,
                cov_inv=cov_inv,
                init_method=init_method,
                max_iter=max_iter,
                tol=tol,
                level=level + 1,
                prefix=current_label
            )

            # вставляем подметки (поддиапазон размерности соответствует idx)
            labels_all[idx, level:] = sub_labels[:, level:]

        # Если на последнем шаге — доводим прогресс до 100%
        if level == 1:
            self._global_progress_counter = total
            self.signals.progress_signal.emit(100)
            self.signals.progress_status.emit("Progress status: done!")
            self._log("=== DICHOTOMIC FINISHED ===")

        return labels_all

    def run(self):

        try:
            dataset = gdal.Open(self.raster_source)
            if not dataset:
                raise Exception(f"Raster could not be opened: {self.raster_source}")
            
            proj_wkt = dataset.GetProjection()
            raster_srs = osr.SpatialReference()
            raster_srs.ImportFromWkt(proj_wkt)
            if raster_srs.IsGeographic():
                raise Exception("Raster is in geographic CRS (e.g., EPSG:4326). Please reproject to a projected CRS.")

            band_data = []
            for i in self.selected_bands:
                band_obj = dataset.GetRasterBand(i)
                nodata = band_obj.GetNoDataValue()
                band = band_obj.ReadAsArray().astype('float32')
                band[band == nodata] = np.nan
                band_data.append(band)

            array3d = np.dstack(band_data)
            rows, cols, bands = array3d.shape
            array2d = array3d.reshape((rows * cols, bands))
            self._log(f"Metric: {self.metric}")
            self._log(f"Initialization method: {self.init_method}.")
            self._log(f"Source array [pixels, channels] shape: {array2d.shape}")

            # Очистим данные от NaN один раз, чтобы все функции работали с чистым массивом
            valid_mask = ~np.isnan(array2d).any(axis=1)
            clean_data = array2d[valid_mask].astype('float32')
            self._log(f"Array [pixels, channels] shape (without pixels with NaN): {clean_data.shape}")

            # Предварительно вычислим обратную ковариационную матрицу для метрики Фишера
            cov_inv = None
            if self.metric == 'Fisher':
                self.signals.progress_status.emit("Progress status: covariance matrix calculation...")
                cov = np.cov(clean_data, ddof=1, rowvar=False)
                
                try:
                    cov_inv = np.linalg.inv(cov)
                except LinAlgError:
                    eps = 1e-8 * np.mean(np.diag(cov)) if np.mean(np.diag(cov)) != 0 else 1e-8
                    cov_reg = cov + eps * np.eye(cov.shape[0])
                    try:
                        cov_inv = np.linalg.inv(cov_reg)
                    except LinAlgError:
                        cov_inv = np.linalg.pinv(cov_reg)

            # --- дихотомическая кластеризация ---
            labels_all = self._dichotomic_kmeans(
                clean_data,
                levels=self.levels,
                metric=self.metric,
                cov_inv=cov_inv,
                init_method=self.init_method,
                max_iter=self.max_iter,
                tol=self.tol
            )

            # --- восстановление NaN ---
            N_total = array2d.shape[0]
            full_labels = np.full((N_total, self.levels), np.nan, dtype=np.float32)
            full_labels[valid_mask, :] = labels_all.astype(np.float32)

            # --- в 3D (rows, cols, levels) ---
            rows, cols = dataset.RasterYSize, dataset.RasterXSize
            result_3d = full_labels.reshape((rows, cols, self.levels))
            
            dataset = None

            log_text = self._get_log_report()

            self.signals.progress_status.emit('Progress status: done!')
            self.signals.progress_signal.emit(100)

            self._dichotomous_result = result_3d
            self._report = log_text

            return True
    
        except Exception as e:
            self.signals.exception_signal.emit(str(e))
            return False
    
    def finished(self, result):
        """Mетод вызывается автоматически в главном потоке после run()."""

        if self.isCanceled():
            # Задача была отменена пользователем
            self.signals.canceled_signal.emit()
            self.signals.progress_status.emit(f"Compute raster dichotomous task canceled.")
            self.signals.progress_signal.emit(0)
        elif result:
            # Успешное завершение — теперь можно безопасно работать с GUI
            self.signals.dichotomous_labels_signal.emit(self._dichotomous_result)
            self.signals.log_report_signal.emit(self._report)
            self.signals.html_report_signal.emit(self._html_report)
            self.signals.finished_signal.emit()
        else:
            # Ошибка или сбой
            self.signals.progress_status.emit(f"Compute raster dichotomous task failed.")
            self.signals.progress_signal.emit(0)
    