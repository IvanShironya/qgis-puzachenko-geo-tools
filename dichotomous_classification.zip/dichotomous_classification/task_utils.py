# -*- coding: utf-8 -*-

"""
/***************************************************************************
TaskSignals
                                 A QGIS plugin
 Dichotomous k-means Classification
                              -------------------
        changed              : 2026-03-11
        begin                : 2025-10-07
        version              : 1.0
        git sha              : $Format:%H$
        copyright            : (C) 2025-2026 by I. Shironya
        email                : ivan.shironya@gmail.com
 ***************************************************************************/
"""


from PyQt5.QtCore import QObject, pyqtSignal


class TaskSignals(QObject):
    """Универсальный набор сигналов для задач QGIS Task."""

    progress_status = pyqtSignal(str)
    exception_signal = pyqtSignal(str)
    progress_signal = pyqtSignal(int)
    log_report_signal = pyqtSignal(str)
    html_report_signal = pyqtSignal(list)
    dichotomous_labels_signal = pyqtSignal(object)

    finished_signal = pyqtSignal()
    canceled_signal = pyqtSignal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
