# -*- coding: utf-8 -*-

"""
/***************************************************************************
QgsTaskRasterDichotomousByMask
 
                                 A QGIS plugin
 Dichotomous k-means Classification
                             -------------------
        changed              : 2026-03-11
        begin                : 2025-10-07
        version              : 1.0
        git sha              : $Format:%H$
        copyright            : (C) 2025-2026 by I. Shironya
        email                : ivan.shironya@gmail.com
 ***************************************************************************/
"""


from qgis.core import (
    QgsTask, 
    QgsVectorLayer, 
    QgsCoordinateReferenceSystem, 
    QgsRectangle, 
    QgsVectorFileWriter, 
    QgsWkbTypes, 
    QgsFeature
)
from osgeo import gdal, osr, ogr
import numpy as np
from numpy.linalg import LinAlgError
import tempfile
import os

from .qgstask_raster_dichotomous import QgsTaskRasterDichotomous
from .task_utils import TaskSignals


class QgsTaskRasterDichotomousByMask(QgsTask):
    """
    Выполняет дихотомическую классификацию растра в границах векторной маски по каждому уникальному коду.
    """

    def __init__(
        self,
        raster_source,
        mask_layer: QgsVectorLayer,
        mask_field: str,
        selected_bands,
        init_method="Synthetic vectors",
        metric="Euclidean",
        levels=1,
        max_iter=100,
        tol=1e-6,
        min_cluster_size=2,
        internal_buffer=0,
        quadrant_segments=8,
        description="Compute Raster Dichotomous by Mask",
    ):
        super().__init__(description, QgsTask.CanCancel)
        self.signals = TaskSignals()

        self.raster_source = raster_source
        self.mask_layer = mask_layer
        self.mask_field = mask_field
        self.selected_bands = selected_bands
        self.init_method = init_method
        self.metric = metric
        self.levels = levels
        self.max_iter = max_iter
        self.tol = tol
        self.min_cluster_size = min_cluster_size
        self.internal_buffer = internal_buffer
        self.quadrant_segments = quadrant_segments

        self._result = None
        self._report = ""
        self._html_report = []  # список словарей для структурированного отчета

    def _log(self, msg):
        self._report += str(msg) + "\n"

    def run(self):

        try:
            dataset = gdal.Open(self.raster_source)
            if not dataset:
                raise Exception(f"Raster could not be opened: {self.raster_source}")

            gt = dataset.GetGeoTransform()
            proj = dataset.GetProjection()
            rows, cols = dataset.RasterYSize, dataset.RasterXSize

            # === Проверка CRS растра ===
            raster_srs = osr.SpatialReference()
            raster_srs.ImportFromWkt(proj)
            if raster_srs.IsGeographic():
                raise Exception("Raster is in geographic CRS (e.g., EPSG:4326). Please reproject to a projected CRS.")

            # === Проверка CRS вектора ===
            mask_crs = self.mask_layer.crs()
            raster_crs = QgsCoordinateReferenceSystem(raster_srs.ExportToWkt())
            if mask_crs != raster_crs:
                raise Exception("CRS mismatch: reproject mask layer to match raster CRS.")

            # === Проверка пересечения экстентов ===
            raster_extent = QgsRectangle(
                gt[0],
                gt[3] + gt[5] * rows,
                gt[0] + gt[1] * cols,
                gt[3],
            )

            if not raster_extent.intersects(self.mask_layer.extent()):
                raise Exception("Mask does not intersect raster extent.")

            # ===== ЛОГ по пересечениям =====
            intersecting_ids = []
            non_intersecting_ids = []
            for f in self.mask_layer.getFeatures():
                if f.geometry().intersects(raster_extent):
                    intersecting_ids.append(f.id())
                else:
                    non_intersecting_ids.append(f.id())
            
            self._log(f"Metric: {self.metric}")
            self._log(f"Initialization method: {self.init_method}")
            self._log(f"{len(intersecting_ids)} polygons intersect raster; {len(non_intersecting_ids)} do not")

            # === Загрузка выбранных каналов ===
            band_data = []
            for i in self.selected_bands:
                band = dataset.GetRasterBand(i).ReadAsArray().astype("float32")
                nodata = dataset.GetRasterBand(i).GetNoDataValue()
                if nodata is not None:
                    band[band == nodata] = np.nan
                band_data.append(band)

            raster_array = np.dstack(band_data)
            self._log(f"Raster loaded: {rows}x{cols}, {len(self.selected_bands)} bands")

            # === Выделение уникальных кодов ===
            unique_codes = sorted(
                {f[self.mask_field] for f in self.mask_layer.getFeatures() if f[self.mask_field] is not None}
            )
            if not unique_codes:
                raise Exception("No valid mask codes found in mask field.")

            result_3d = np.full((rows, cols, self.levels), np.nan, dtype=np.float32)
            total_codes = len(unique_codes)
            self._log(f"Found {total_codes} unique mask codes: {unique_codes}")

            # === СОЗДАНИЕ ВРЕМЕННОГО ЛЕЙЕРА С БУФЕРОМ ===
            buffered_path = os.path.join(tempfile.gettempdir(), "mask_buffered.shp")

            writer = QgsVectorFileWriter(
                buffered_path,
                "UTF-8",
                self.mask_layer.fields(),
                QgsWkbTypes.Polygon,
                self.mask_layer.crs(),
                "ESRI Shapefile"
            )

            for f in self.mask_layer.getFeatures():
                geom = f.geometry()
                if self.internal_buffer != 0:
                    geom = geom.buffer(self.internal_buffer, self.quadrant_segments)

                # Проверка валидности геометрии
                if not geom.isGeosValid():
                    self._log(f"Missing polygon {f.id()}: invalid geometry")
                    continue  # Пропускаем невалидные геометрии

                new_feat = QgsFeature()
                new_feat.setFields(self.mask_layer.fields())
                new_feat.setGeometry(geom)
                new_feat.setAttributes(f.attributes())
                writer.addFeature(new_feat)

            del writer  # важно!

            shp_path = buffered_path

            # === Цикл по кодам ===
            for idx, code in enumerate(unique_codes):
                if self.isCanceled():
                    self._log("Task canceled by user.")
                    return False

                self.signals.progress_status.emit(
                    f"Progress status: processing mask code {code} ({idx+1}/{total_codes})..."
                )

                # =====================================================================
                # 1) РАСТЕРИЗАЦИЯ ЧЕРЕЗ OGR (ТОЛЬКО ДЛЯ SHP!)
                # =====================================================================
                tmp_mask_path = os.path.join(tempfile.gettempdir(), f"mask_code_{code}.tif")
                drv = gdal.GetDriverByName("GTiff")
                mask_ds = drv.Create(tmp_mask_path, cols, rows, 1, gdal.GDT_Byte)
                mask_ds.SetGeoTransform(gt)
                mask_ds.SetProjection(proj)

                # Открываем SHP через OGR
                ogr_ds = ogr.Open(shp_path)
                if ogr_ds is None:
                    raise Exception(f"Could not open shapefile via OGR: {shp_path}")

                ogr_layer = ogr_ds.GetLayer(0)

                # Устанавливаем атрибутивный фильтр
                ogr_layer.SetAttributeFilter(f"{self.mask_field} = {int(code)}")

                # Растеризуем
                gdal.RasterizeLayer(mask_ds, [1], ogr_layer, burn_values=[1])

                # Сбрасываем фильтр
                ogr_layer.SetAttributeFilter(None)

                # Читаем маску
                mask_array = mask_ds.ReadAsArray().astype(bool)
                mask_ds = None

                # =====================================================================

                # === 2) Извлечение пикселей ===
                masked_pixels = raster_array[mask_array]

                if masked_pixels.size == 0:
                    self._log(f"Code {code}: no pixels found under mask, skipping.")
                    continue

                # Удаление NaN (строки, где есть хотя бы один NaN)
                valid_mask = ~np.isnan(masked_pixels).any(axis=1)
                clean_pixels = masked_pixels[valid_mask]

                if clean_pixels.size == 0:
                    self._log(f"Code {code}: all pixels contain NaN, skipping.")
                    continue

                # === 3) Запуск дихотомической классификации ===
                subtask = QgsTaskRasterDichotomous(
                    raster_source=self.raster_source,
                    selected_bands=self.selected_bands,
                    init_method=self.init_method,
                    metric=self.metric,
                    levels=self.levels,
                    max_iter=self.max_iter,
                    tol=self.tol,
                    min_cluster_size=self.min_cluster_size
                )

                # Предварительно вычислим обратную ковариационную матрицу, если метрика Фишера
                cov_inv = None
                if self.metric == 'Fisher':
                    self.signals.progress_status.emit("Progress status: covariance matrix calculation...")
                    cov = np.cov(clean_pixels, ddof=1, rowvar=False)
                    
                    try:
                        cov_inv = np.linalg.inv(cov)
                    except LinAlgError:
                        eps = 1e-8 * np.mean(np.diag(cov)) if np.mean(np.diag(cov)) != 0 else 1e-8
                        cov_reg = cov + eps * np.eye(cov.shape[0])
                        try:
                            cov_inv = np.linalg.inv(cov_reg)
                        except LinAlgError:
                            cov_inv = np.linalg.pinv(cov_reg)
                
                self.signals.progress_status.emit(f"Progress status: processing dichotomic k-means for mask code {code}...")
                # запуск дихотомической кластеризации на данных из маски
                labels_all = subtask._dichotomic_kmeans(
                    clean_pixels,
                    levels=self.levels,
                    metric=self.metric,
                    cov_inv=cov_inv,
                    init_method=self.init_method,
                    max_iter=self.max_iter,
                    tol=self.tol,
                    level=1,
                )

                # --- Обработка html_report подзадачи ---
                if hasattr(subtask, "_html_report"):
                    for entry in subtask._html_report:
                        # добавляем mask code к каждой записи
                        entry_with_code = entry.copy()
                        entry_with_code['mask_code'] = code
                        self._html_report.append(entry_with_code)

                # подробный лог от subtask
                sub_log = subtask._get_log_report()

                self._log(f"\n============================")
                self._log(f" LOG FOR MASK CODE {code} ")
                self._log(f"============================\n")
                self._log(sub_log)
                self._log(f"========== END CODE {code} ==========\n")

                # === 4) Запись результата ===
                for lvl in range(self.levels):
                    lvl_data = labels_all[:, lvl]

                    # исходный массив для всех пикселей маски
                    full_lvl = result_3d[:, :, lvl][mask_array]

                    # вставляем значения только для валидных пикселей
                    full_lvl[valid_mask] = lvl_data

                    # возвращаем всё назад
                    result_3d[:, :, lvl][mask_array] = full_lvl

                # === 5) Прогресс ===
                progress = int(((idx + 1) / total_codes) * 100)
                self.signals.progress_signal.emit(progress)

            dataset = None

            self._result = result_3d
            self.signals.progress_signal.emit(100)
            self.signals.progress_status.emit("Progress status: done!")
            self._log("All mask codes processed successfully.")
            return True

        except Exception as e:
            self.signals.exception_signal.emit(str(e))
            return False

    def finished(self, result):
        """Вызывается автоматически в главном потоке."""

        if self.isCanceled():
            self.signals.canceled_signal.emit()
            self.signals.progress_status.emit("Task canceled.")
            self.signals.progress_signal.emit(0)
        elif result:
            self.signals.dichotomous_labels_signal.emit(self._result)
            self.signals.log_report_signal.emit(self._report)
            self.signals.html_report_signal.emit(self._html_report)
            self.signals.finished_signal.emit()
        else:
            self.signals.progress_status.emit("Task failed.")
            self.signals.progress_signal.emit(0)
