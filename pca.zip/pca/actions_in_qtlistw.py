# -*- coding: utf-8 -*-


from PyQt5.QtWidgets import QListWidget, QApplication, QMenu, QAction
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QDrag

class ActionsInListWidget(QListWidget):
    '''
    Класс добавляет дополнительные функции к QListWidget, 
    реализуя функции перетаскивания, выбора и контекстного меню
    удаления элементов
    '''

    def __init__(self, parent=None):
        super(ActionsInListWidget, self).__init__(parent)

        # Установим режим перетаскивания InternalMove
        self.setDragDropMode(QListWidget.InternalMove)

        # Установим режим выбора ExtendedSelection
        self.setSelectionMode(QListWidget.ExtendedSelection)

        # Установим для политики контекстного меню значение CustomContextMenu
        self.setContextMenuPolicy(Qt.CustomContextMenu)

        # Подключим сигнал customContextMenuRequested к showContextMenu
        self.customContextMenuRequested.connect(self.show_context_menu)
        
    def mouse_press_event(self, event):
        '''
        Метод сохраняет начальную позицию щелчка мыши 
        при нажатии левой кнопки
        '''
        
        if event.button() == Qt.LeftButton:
            self.drag_start_pos = event.pos()
        super(ActionsInListWidget, self).mousePressEvent(event)
        
    def mouse_move_event(self, event):
        '''
        Метод вызывается при перемещении мыши. 
        Если расстояние между начальной и текущей позицией больше или 
        равно значению QApplication.startDragDistance(), инициируется 
        операция перетаскивания. Выбранные элементы добавляются к 
        mime-данным перетаскиваемого объекта, и перетаскивание выполняется 
        с помощью метода Qt.MoveAction. Если действие удаления прошло успешно, 
        событие принимается.
        '''

        if event.buttons() == Qt.LeftButton:
            distance = (event.pos() - self.drag_start_pos).manhattanLength()
            if distance >= QApplication.startDragDistance():
                selected_items = self.selectedItems()
                if selected_items:
                    mime_data = self.mimeData(selected_items)
                    drag = QDrag(self)
                    drag.setMimeData(mime_data)
                    drop_action = drag.exec_(Qt.MoveAction)
                    if drop_action == Qt.MoveAction:
                        event.accept()
    
    def show_context_menu(self, pos):
        '''Метод для отображения контекстного меню по запросу'''

        menu = QMenu(self)
        delete_action = QAction("Delete", self)
        delete_action.triggered.connect(self.delete_selected_items)
        menu.addAction(delete_action)
        menu.exec_(self.mapToGlobal(pos))
    
    def delete_selected_items(self):
        '''Метод удаления выбранных элементов из списка'''

        selected_items = self.selectedItems()
        for item in selected_items:
            self.takeItem(self.row(item))
        