# import os

# file_paths = ['D:/pythonPRJ_homePC/qgis/test_dataset_for_lda/test_tifs/sc1.tif', 'D:/pythonPRJ_homePC/qgis/test_dataset_for_lda/test_tifs/sc2.tif', 'D:/pythonPRJ_homePC/qgis/test_dataset_for_lda/test_tifs/sc3.tif', 'D:/pythonPRJ_homePC/qgis/test_dataset_for_lda/test_tifs/sc4.tif', 'D:/pythonPRJ_homePC/qgis/test_dataset_for_lda/test_tifs/sc5.tif', 'D:/pythonPRJ_homePC/qgis/test_dataset_for_lda/test_tifs/dd6.tif', 'D:/pythonPRJ_homePC/qgis/test_dataset_for_lda/test_tifs/kjjhhg2.tif']

# # Extract the file names from the file paths
# file_names = [os.path.basename(file_path) for file_path in file_paths]

# # Filter the file names based on the given list
# filtered_file_names = ['dd6.tif', 'sc2.tif', 'sc5.tif', 'sc1.tif']
# filtered_file_paths = [file_path for file_path in file_paths if os.path.basename(file_path) in filtered_file_names]

# print(filtered_file_paths)


import numpy as np
# import cProfile

# def calculate_covariance_matrix():
#     random_matrix = np.random.rand(5000, 5000)
#     covariance_matrix = np.cov(random_matrix)
#     return covariance_matrix

# cProfile.run('calculate_covariance_matrix()')

import numpy as np

matrix_with_nan = np.random.rand(5, 5)
matrix_with_nan[np.random.choice([True, False], size=(5, 5), p=[0.1, 0.9])] = np.nan

print(matrix_with_nan)

corr = np.ma.corrcoef(np.ma.masked_invalid(matrix_with_nan), rowvar=False)
print(corr)

# Замена NaN на нули
matrix_with_nan[np.isnan(matrix_with_nan)] = 0

# Расчет корреляционной матрицы
correlation_matrix = np.corrcoef(matrix_with_nan)
print(correlation_matrix)

